document.getElementById("searchForm").addEventListener("submit", function(event) {
  event.preventDefault();

  let origin = document.getElementById("origin").value;
  let destination = document.getElementById("destination").value;
  let departure = document.getElementById("departure").value;
  let travellers = document.getElementById("travellers").value;
  let travelClass = document.getElementById("class").value;

  // Dummy validation logic (replace with actual validation)
  if (!origin || !destination || !departure || !travellers || !travelClass) {
    showMessage("All fields are mandatory.");
    return;
  }

  // Dummy search logic (replace with actual search functionality)
  showMessage("Searching flights...", "green");
  // Replace with actual search implementation or API call
  // This is just a placeholder to demonstrate functionality
});

function showMessage(message, color = "black") {
  alert(message); // Replace with actual UI message display
}
