document.getElementById("registrationForm").addEventListener("submit", function(event) {
  event.preventDefault();

  let firstName = document.getElementById("firstName").value;
  let lastName = document.getElementById("lastName").value;
  let dob = document.getElementById("dob").value;
  let email = document.getElementById("email").value;
  let address = document.getElementById("address").value;
  let contactNumber = document.getElementById("contactNumber").value;

  // Dummy validation logic (replace with actual validation)
  if (!firstName || !lastName || !dob || !email || !address || !contactNumber) {
    showMessage("All fields are mandatory.");
    return;
  }

  // Dummy validation for date format
  let dobDate = new Date(dob);
  let minDate = new Date("1924-01-01");
  if (dobDate <= minDate) {
    showMessage("Choose a date greater than 1/1/1924.");
    return;
  }

  // Dummy validation for contact number
  if (contactNumber.length !== 10) {
    showMessage("Enter a valid contact number.");
    return;
  }

  // Dummy validation for email format
  let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    showMessage("Enter a valid email.");
    return;
  }

  // Registration successful message (replace with actual backend integration)
  showMessage("Passenger Registration successful!", "green");
  // Redirect to login page or perform other actions
  // Replace with actual redirect logic if needed
  setTimeout(function() {
    window.location.href = "login.html"; // Redirect to login page
  }, 1000);
});

function showMessage(message, color = "red") {
  let messageElement = document.getElementById("registrationMessage");
  messageElement.textContent = message;
  messageElement.style.color = color;
}
