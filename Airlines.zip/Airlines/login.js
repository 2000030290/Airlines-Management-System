document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();

  let userId = document.getElementById("userId").value;
  let password = document.getElementById("password").value;

  // Dummy validation logic (replace with actual validation)
  if (!userId || !password) {
    showMessage("User ID and Password are required.");
    return;
  }

  // Dummy logic for authentication (replace with actual backend integration)
  const validUserIds = ["12345", "67890", "24680"];
  const validPasswords = ["pass123", "admin@123", "user456"];

  let isValidUser = false;
  let isValidPassword = false;

  for (let i = 0; i < validUserIds.length; i++) {
    if (userId === validUserIds[i]) {
      isValidUser = true;
      if (password === validPasswords[i]) {
        isValidPassword = true;
        break;
      }
    }
  }

  if (!isValidUser) {
    showMessage("ID not valid");
  } else if (!isValidPassword) {
    showMessage("Password not valid");
  } else {
    showMessage("Login successful!", "green");
    // Redirect to home page or perform other actions
    // Replace with actual redirect logic if needed
    setTimeout(function() {
      window.location.href = "home.html"; // Redirect to home page
    }, 1000);
  }
});

function showMessage(message, color = "red") {
  let messageElement = document.getElementById("loginMessage");
  messageElement.textContent = message;
  messageElement.style.color = color;
}
