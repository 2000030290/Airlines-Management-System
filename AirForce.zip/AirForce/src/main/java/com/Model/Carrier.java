package com.Model;

public class Carrier {
	String cname;
	int ad30;
	int ad60;
	int ad90;
	int bbook;
	int silver;
	int gold;
	int platinum;
	int refund2;
	int refund10;
	int refund20;
	int cid;
	
	public Carrier(String cname, int ad30, int ad60, int ad90, int bbook, int silver, int gold,
			int platinum, int refund2, int refund10, int refund20) {

		this.cname = cname;
		this.ad30 = ad30;
		this.ad60 = ad60;
		this.ad90 = ad90;
		this.bbook = bbook;
		this.silver = silver;
		this.gold = gold;
		this.platinum = platinum;
		this.refund2 = refund2;
		this.refund10 = refund10;
		this.refund20 = refund20;
	}
	public Carrier() {
	}
	public int getCid()
	{
		return cid;
	}
	public void setCid(int cid)
	{
		this.cid=cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getAd30() {
		return ad30;
	}
	public void setAd30(int ad30) {
		this.ad30 = ad30;
	}
	public int getAd60() {
		return ad60;
	}
	public void setAd60(int ad60) {
		this.ad60 = ad60;
	}
	public int getAd90() {
		return ad90;
	}
	public void setAd90(int ad90) {
		this.ad90 = ad90;
	}
	public int getBbook() {
		return bbook;
	}
	public void setBbook(int bbook) {
		this.bbook = bbook;
	}
	public int getSilver() {
		return silver;
	}
	public void setSilver(int silver) {
		this.silver = silver;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getPlatinum() {
		return platinum;
	}
	public void setPlatinum(int platinum) {
		this.platinum = platinum;
	}
	public int getRefund2() {
		return refund2;
	}
	public void setRefund2(int refund2) {
		this.refund2 = refund2;
	}
	public int getRefund10() {
		return refund10;
	}
	public void setRefund10(int refund10) {
		this.refund10 = refund10;
	}
	public int getRefund20() {
		return refund20;
	}
	public void setRefund20(int refund20) {
		this.refund20 = refund20;
	}
	@Override
	public String toString() {
		return "CarrierOp [cname=" + cname + ", ad30=" + ad30 + ", ad60=" + ad60 + ", ad90=" + ad90 + ", bbook=" + bbook
				+ ", silver=" + silver + ", gold=" + gold + ", platinum=" + platinum + ", refund2=" + refund2
				+ ", refund10=" + refund10 + ", refund20=" + refund20 + "]";
	}
}
