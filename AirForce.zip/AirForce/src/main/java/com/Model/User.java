
package com.Model;

import java.sql.Date;

public class User 
{
	String fname;
	String lname;
	Date dob;
	String mail;
	String address;
	long phn;
	int userid;
	String password;
	String cpassword;
	public User(String fname, String lname, Date dob, String mail, String address,long phn, int userid, String password,
			String cpassword) {
		
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.mail = mail;
		this.address = address;
		this.phn = phn;
		this.userid = userid;
		this.password = password;
		this.cpassword = cpassword;
	}

	public User() {
	}

	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public long getPhn() {
		return phn;
	}
	public void setPhn(long phn) {
		this.phn = phn;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	@Override
	public String toString() {
		return "User [fname=" + fname + ", lname=" + lname + ", dob=" + dob + ", mail=" + mail + ", address=" + address
				+ ", phn=" + phn + ", userid=" + userid + ", password=" + password + ", cpassword=" + cpassword + "]";
	}
	
	
}