
package com.Model;

public class Flight {
	int cid;
	String cname;
	String origin;
	String destination;
	int airfare;
	int bclass;
	int eclass;
	int exclass;
	int fid;
	
	public Flight()
	{
		
	}
	public Flight(int cid,String cname, String origin, String destination, int airfare, int bclass, int eclass, int exclass) {

		this.cid=cid;
		this.cname = cname;
		this.origin = origin;
		this.destination = destination;
		this.airfare = airfare;
		this.bclass = bclass;
		this.eclass = eclass;
		this.exclass = exclass;
	}
	public void setFid(int fid)
	{
		this.fid = fid;
	}
	public int getFid()
	{
		return fid;
	}
	public int getCid()
	{
		return cid;
	}
	public void setCid(int cid)
	{
		this.cid=cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getAirfare() {
		return airfare;
	}
	public void setAirfare(int airfare) {
		this.airfare = airfare;
	}
	public int getBclass() {
		return bclass;
	}
	public void setBclass(int bclass) {
		this.bclass = bclass;
	}
	public int getEclass() {
		return eclass;
	}
	public void setEclass(int eclass) {
		this.eclass = eclass;
	}
	public int getExclass() {
		return exclass;
	}
	public void setExclass(int exclass) {
		this.exclass = exclass;
	}
	@Override
	public String toString() {
		return "Flight [cname=" + cname + ", origin=" + origin + ", destination=" + destination + ", airfare=" + airfare
				+ ", bclass=" + bclass + ", eclass=" + eclass + ", exclass=" + exclass + "]";
	}
	
	
}


