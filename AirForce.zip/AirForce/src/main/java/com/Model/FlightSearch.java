package com.Model;

import java.sql.Date;

public class FlightSearch 
{
	int fid;
	String origin;
	String destination;
	Date dot;
	int not;
	String eclass;
	String bclass;
	String exclass;
	public FlightSearch(String origin, String destination, Date dot, int not, String eclass, String bclass,
			String exclass) {
		super();
		this.origin = origin;
		this.destination = destination;
		this.dot = dot;
		this.not = not;
		this.eclass = eclass;
		this.bclass = bclass;
		this.exclass = exclass;
	}
/* create table flightSchedule(fsid int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,fid int,origin varchar(30),destination varchar(50), dot date, eclass int, blass int, exclass int);*/
	
	public FlightSearch() {
	}

	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getOrigin() {
		return origin;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDot() {
		return dot;
	}
	public void setDot(Date dot) {
		this.dot = dot;
	}
	public int getNot() {
		return not;
	}
	public void setNot(int not) {
		this.not = not;
	}
	public String getEclass() {
		return eclass;
	}
	public void setEclass(String eclass) {
		this.eclass = eclass;
	}
	public String getBclass() {
		return bclass;
	}
	public void setBclass(String bclass) {
		this.bclass = bclass;
	}
	public String getExclass() {
		return exclass;
	}
	public void setExclass(String exclass) {
		this.exclass = exclass;
	}
	
	
	
}
