
package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.Model.Carrier;
import com.Model.Flight;
import com.Model.User;

public class CarrierOp 
{
	
	public static int insertCarrier(Carrier e)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "insert into carrier(carriername,dp_thirtydays_ab,dp_sixtydays_ab,dp_ninetydays_ab,bulkbookingdiscount,silveruserdiscount,golduserdiscount,platinumuserdiscount,refund_2d_bt,refund_10d_bt,refund_20d_bt) values(?,?,?,?,?,?,?,?,?,?,?)";
		pst = con.prepareStatement(sql);
		pst.setString(1, e.getCname());
		pst.setInt(2, e.getAd30());
		pst.setInt(3, e.getAd60());
		pst.setInt(4, e.getAd90());
		pst.setInt(5, e.getBbook());
		pst.setInt(6,e.getSilver());
		pst.setInt(7, e.getGold());
		pst.setInt(8,e.getPlatinum() );
		pst.setInt(9, e.getRefund2());
		pst.setInt(10, e.getRefund10());
		pst.setInt(11, e.getRefund20());
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	}
	
	public static int deleteCarrier(int cid)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "delete from carrier where CarrierId=?";
		pst = con.prepareStatement(sql);
		pst.setInt(1, cid);
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	}
	
	public static List<Carrier> findAllCarriers()
	{
		List<Carrier> el = new ArrayList<Carrier>();
		PreparedStatement pst;
		Connection con;
		ResultSet rs;
		try
		{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql ="select * from carrier";
		pst = con.prepareStatement(sql);
		rs = pst.executeQuery();
		while(rs.next())
		{
			
			Carrier e3 = new Carrier();
			e3.setCid(rs.getInt(1));
			e3.setCname(rs.getString(2));
			e3.setAd30(rs.getInt(3));
			e3.setAd60(rs.getInt(4));
			e3.setAd90(rs.getInt(5));
			e3.setBbook(rs.getInt(6));
			e3.setSilver(rs.getInt(7));
			e3.setGold(rs.getInt(8));
			e3.setPlatinum(rs.getInt(9));
			e3.setRefund2(rs.getInt(10));
			e3.setRefund10(rs.getInt(11));
			e3.setRefund20(rs.getInt(12));

			el.add(e3);
			
		
		}
		rs.close();
		pst.close();
		con.close();
		}
		
		catch(Exception s)
		{
			System.out.println(s);
		}
		
		return el;
	}
	
	public static int updateCarrier(Carrier e,int cid)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "update carrier set DP_ThirtyDays_AB=?,DP_SixtyDays_ab=?,DP_NinetyDays_AB=?,BulkBookingDiscount=?,SilverUserDiscount=?,GoldUserDiscount=?,PlatinumUserDiscount=?,Refund_2d_BT=?,"
				+ "Refund_10D_BT=?,Refund_20D_BT=? where carrierId=?";
		
		pst = con.prepareStatement(sql);
		pst.setInt(1, e.getAd30());
		pst.setInt(2, e.getAd60());
		pst.setInt(3, e.getAd90());
		pst.setInt(4, e.getBbook());
		pst.setInt(5, e.getSilver());
		pst.setInt(6, e.getGold());
		pst.setInt(7, e.getPlatinum());
		pst.setInt(8, e.getRefund2());
		pst.setInt(9, e.getRefund10());
		pst.setInt(10, e.getRefund20());
		pst.setInt(11, cid);
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	} 
	
	public static String getCarrierName(int cid)
	{
		Connection con = null;
		PreparedStatement pst;
		ResultSet rs;
		String cname="";
		try{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
			String sql = "select carrierName from carrier where carrierId=?";
			pst = con.prepareStatement(sql);
			pst.setInt(1, cid);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
			 cname=rs.getString("carrierName");
			}
			rs.close();
			pst.close();
			con.close();
			
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return cname;
	}}
//	public static List<Carrier> searchCarrier(int cid)
//	{
//		int check = 0;
//		Connection con = null;
//		PreparedStatement pst;
//		ResultSet rs;
//		String cname="";
//		try{
//		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
//		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
//		String sql = "select carrierName from carrier where carrierId=?";
//		pst = con.prepareStatement(sql);
//		pst.setInt(1, cid);
//		rs=pst.executeQuery();
//		if(rs.next())
//		{
//			cname=rs.getString(2);
//			req.setAttribute("cname",cname);
//		}
//		pst.close();
//		con.close();
//		
//		}
//		catch(Exception ex)
//		{
//			ex.printStackTrace();
//		}
//		return null;
//	}

