
package com.DAO;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.Model.User;

public class UserOp {
	
//	public static String hashPassword(String password)
//	{
//		try
//		{
//			MessageDigest md=MessageDigest.getInstance("SHA-256");
//			byte[] hashedBytes=md.digest(password.getBytes());
//			StringBuilder sb=new StringBuilder();
//			for(byte b: hashedBytes)
//			{
//				sb.append(String.format("%02x", b));
//			}
//			return sb.toString();
//		}
//		catch(NoSuchAlgorithmException e)
//		{
//			throw new RuntimeException(e);
//		}
//	}
	
	public static int insertUser(User e)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "insert into users values(?,?,?,?,?,?,?,?,?)";
		pst = con.prepareStatement(sql);
		//String hashedpassword=hashPassword(e.getPassword());
		pst.setString(1, e.getFname());
		pst.setString(2, e.getLname());
		pst.setDate(3, e.getDob());
		pst.setString(4, e.getMail());
		pst.setString(5, e.getAddress());
		pst.setLong(6,e.getPhn());
		pst.setInt(7, e.getUserid());
		pst.setString(8,e.getPassword());
		pst.setString(9, e.getCpassword());
		check = pst.executeUpdate();
		//System.out.println(check);
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	}
	public static String usedDet(int userid)
	{
		
		String pwdd = "";
	
		Connection con= null;
		PreparedStatement pst = null;	
		ResultSet rs =null;
		try
		{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
	        String sql = "SELECT  password FROM users where userid=? ";
	        pst = con.prepareStatement(sql);
	        pst.setLong(1,userid);
	        rs = pst.executeQuery();
	while(rs.next())
	 {
//	 id=rs.getString("id");
	pwdd=rs.getString("password");   
	
	}
	//System.out.println(pwdd);
       

    rs.close();
    pst.close();
    con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return pwdd;
		
	}
	
	
	public static List<User> findAllUsers()
	{
		List<User> el = new ArrayList<User>();
		PreparedStatement pst;
		Connection con;
		ResultSet rs;
		try
		{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql ="select * from users";
		pst = con.prepareStatement(sql);
		rs = pst.executeQuery();
		while(rs.next())
		{
			
			User e3 = new User();
			e3.setFname(rs.getString(1));
			e3.setLname(rs.getString(2));
			e3.setDob(rs.getDate(3));
			e3.setMail(rs.getString(4));
			e3.setAddress(rs.getString(5));
			e3.setPhn(rs.getLong(6));
			e3.setUserid(rs.getInt(7));
			e3.setPassword(rs.getString(8));
			el.add(e3);
			
		
		}
		rs.close();
		pst.close();
		con.close();
		}
		
		catch(Exception s)
		{
			System.out.println(s);
		}
		
		return el;
	}
}
	