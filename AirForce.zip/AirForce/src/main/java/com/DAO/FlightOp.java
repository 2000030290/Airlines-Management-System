package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.Model.Carrier;
import com.Model.Flight;
import com.Model.User;

public class FlightOp {
	public static int insertFlight(Flight e)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "insert into flight(cid,cname,Origin,Destination,AirFare,SeattCapacityEC,SeatCapacityBC,SeatCapacityExC) values(?,?,?,?,?,?,?,?)";
		pst = con.prepareStatement(sql);
		pst.setInt(1, e.getCid());
		pst.setString(2, e.getCname());
		pst.setString(3, e.getOrigin());
		pst.setString(4, e.getDestination());
		pst.setInt(5, e.getAirfare());
		pst.setInt(6, e.getEclass());
		pst.setInt(7,e.getBclass());
		pst.setInt(8, e.getExclass());
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	}
	
	public static int deleteFlight(int cid)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "delete from flight where cid=?";
		pst = con.prepareStatement(sql);
		pst.setInt(1, cid);
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	}
	
	public static List<Flight> findAllFlights()
	{
		List<Flight> el = new ArrayList<Flight>();
		PreparedStatement pst;
		Connection con;
		ResultSet rs;
		try
		{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql ="select * from flight";
		pst = con.prepareStatement(sql);
		rs = pst.executeQuery();
		while(rs.next())
		{
			
			Flight e3 = new Flight();
			e3.setFid(rs.getInt(1));
			e3.setCid(rs.getInt(2));
			e3.setCname(rs.getString(3));
			e3.setOrigin(rs.getString(4));
			e3.setDestination(rs.getString(5));
			e3.setAirfare(rs.getInt(6));
			e3.setBclass(rs.getInt(7));
			e3.setEclass(rs.getInt(8));
			e3.setExclass(rs.getInt(9));
			el.add(e3);
			
		
		}
		rs.close();
		pst.close();
		con.close();
		}
		
		catch(Exception s)
		{
			System.out.println(s);
		}
		
		return el;
	}

	public static String getCarrierName(int cid) {
		Connection con = null;
		PreparedStatement pst;
		ResultSet rs;
		String cname="";
		try{
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
			String sql = "select cname from flight where cid=?";
			pst = con.prepareStatement(sql);
			pst.setInt(1, cid);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
			 cname=rs.getString("cname");
			}
			rs.close();
			pst.close();
			con.close();
			
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return cname;

	}
	
	
	public static int updateFlight(Flight e,int cid)
	{
		int check = 0;
		Connection con = null;
		PreparedStatement pst;
		try{
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql = "update flight set Origin=?,Destination=?,AirFare=?,SeattCapacityEC=?,SeatCapacityBC=?,SeatCapacityExC=? where cid=?";
		
		pst = con.prepareStatement(sql);
		
		pst.setString(1, e.getOrigin());
		pst.setString(2, e.getDestination());
		pst.setInt(3, e.getAirfare());
		pst.setInt(4, e.getEclass());
		pst.setInt(5, e.getBclass());
		pst.setInt(6, e.getExclass());
		pst.setInt(7, cid);
		check = pst.executeUpdate();
		pst.close();
		con.close();
		
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return check;
	} 
	public static List<Flight> SearchFlights(String origin,String destination)
	{
		List<Flight> el = new ArrayList<Flight>();
		PreparedStatement pst;
		Connection con;
		ResultSet rs;
		try
		{
		
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con = DriverManager.getConnection("jdbc:derby:D:\\Users\\2733740\\MyDBServlet;create=true");
		String sql ="select * from flight where origin=? and destination = ?";
		pst = con.prepareStatement(sql);
		pst.setString(1,origin);
		pst.setString(2, destination);
		rs = pst.executeQuery();
		
		while(rs.next())
		{
			
			Flight e3 = new Flight();
			e3.setFid(rs.getInt(1));
			e3.setCid(rs.getInt(2));
			e3.setCname(rs.getString(3));
			e3.setOrigin(rs.getString(4));
			e3.setDestination(rs.getString(5));
			e3.setAirfare(rs.getInt(6));
			e3.setBclass(rs.getInt(7));
			e3.setEclass(rs.getInt(8));
			e3.setExclass(rs.getInt(9));
			el.add(e3);
		
		}
		rs.close();
		pst.close();
		con.close();
		}
		
		catch(Exception s)
		{
			System.out.println(s);
		}
		
		return el;
	}


}

