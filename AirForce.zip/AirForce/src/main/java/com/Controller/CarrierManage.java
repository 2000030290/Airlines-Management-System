package com.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.Model.Carrier;

@WebServlet("/cdelete")
public class CarrierManage extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	int cid=Integer.parseInt(req.getParameter("cid"));
	
	if(req.getParameter("ams").equalsIgnoreCase("CDelete"))
	{
		CarrierOp.deleteCarrier(Integer.parseInt(req.getParameter("cid")));
		resp.sendRedirect("editcarrier.jsp");
	}
	
	if(req.getParameter("ams").equalsIgnoreCase("CEdit"))
	{
		
		String cname = CarrierOp.getCarrierName(cid);
		req.setAttribute("cid",cid);
		req.setAttribute("cname",cname);
			RequestDispatcher r=req.getRequestDispatcher("updatecarrier.jsp");
			r.forward(req, resp);
	}
	}
	
	
	
}
