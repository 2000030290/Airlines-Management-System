package com.Controller;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.UserOp;
import com.Model.*;
@WebServlet("/viewusers")
public class AdminPage extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<User> ulist=new ArrayList<>();
		ulist = UserOp.findAllUsers();
		req.setAttribute("ulist", ulist);
		req.getRequestDispatcher("viewusers.jsp").forward(req, resp);
	}
	

}