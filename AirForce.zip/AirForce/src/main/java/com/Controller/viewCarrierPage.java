
package com.Controller;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.Model.*;
@WebServlet("/viewcarrier")
public class  viewCarrierPage extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Carrier> clist=new ArrayList<>();
		clist = CarrierOp.findAllCarriers();
		req.setAttribute("clist", clist);
		req.getRequestDispatcher("viewcarrier.jsp").forward(req, resp);
	}
	

}