
package com.Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.DAO.FlightOp;

@WebServlet("/flydelete")
public class FlightManage extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	int cid=Integer.parseInt(req.getParameter("cid"));
	if(req.getParameter("ams").equalsIgnoreCase("DeleteFlight"))
	{
		FlightOp.deleteFlight(Integer.parseInt(req.getParameter("cid")));
		resp.sendRedirect("adminhome.jsp");
	}
	
	if(req.getParameter("ams").equalsIgnoreCase("EditFlight"))
	{
		String cname = FlightOp.getCarrierName(cid);
		req.setAttribute("cid",cid);
		req.setAttribute("cname",cname);
			RequestDispatcher r=req.getRequestDispatcher("updateflight.jsp");
			r.forward(req, resp);
	}
	}
}
