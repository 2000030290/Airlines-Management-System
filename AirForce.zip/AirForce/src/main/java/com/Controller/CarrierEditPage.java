package com.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.Model.Carrier;

@WebServlet("/carrieredit")
public class CarrierEditPage extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	int cid=Integer.parseInt(req.getParameter("cid"));
	
	String cname = req.getParameter("cname");
	System.out.println(cname);
	int ad30 = Integer.parseInt(req.getParameter("ad30"));
	int ad60 = Integer.parseInt(req.getParameter("ad60"));
	int ad90 = Integer.parseInt(req.getParameter("ad90"));
	int bbook = Integer.parseInt(req.getParameter("bbook"));
	int silver = Integer.parseInt(req.getParameter("silver"));
	int gold = Integer.parseInt(req.getParameter("gold"));
	int plat = Integer.parseInt(req.getParameter("plat"));
	int refund2 = Integer.parseInt(req.getParameter("refund2"));
	int refund10 = Integer.parseInt(req.getParameter("refund10"));
	int refund20 = Integer.parseInt(req.getParameter("refund20"));
	
	if(req.getParameter("ams").equalsIgnoreCase("editcarrier"))
	{
		Carrier c=new Carrier(cname,ad30,ad60,ad90,bbook,silver,gold,plat,refund2,refund10,refund20);
		CarrierOp.updateCarrier(c, cid);
		resp.sendRedirect("editcarrier.jsp");
	}
	}
	
	
	
}