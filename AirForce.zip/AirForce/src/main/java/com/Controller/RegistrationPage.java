
package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.UserOp;
import com.Model.User;

@WebServlet("/reg")
public class RegistrationPage extends HttpServlet{

		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String fname = req.getParameter("fname");
			String lname = req.getParameter("lname");
			String d = (req.getParameter("dob"));
			Date dob  = Date.valueOf(d);
			String mail = req.getParameter("mail");
			String address = req.getParameter("address");
			long phn = Long.parseLong(req.getParameter("phn"));
			int userid = Integer.parseInt(req.getParameter("userid"));
			String password = req.getParameter("password");
			String cpassword = req.getParameter("cpassword");
		String s = "";
				try
				{
					MessageDigest md=MessageDigest.getInstance("SHA-256");
					byte[] hashedBytes=md.digest(password.getBytes());
					StringBuilder sb=new StringBuilder();
					for(byte b: hashedBytes)
					{
						sb.append(String.format("%02x", b));
					}
					s = sb.toString();
				}
				catch(NoSuchAlgorithmException e)
				{
					throw new RuntimeException(e);
				}
			
			//String mname = ServletOp.getmname(name);
			
			
			if(req.getParameter("am").equalsIgnoreCase("Login"))
			{
				resp.sendRedirect("login.jsp");
			}
			if(req.getParameter("am").equalsIgnoreCase("Register"))
			{
				PrintWriter out = resp.getWriter();
				User u ;
				u =new User(fname, lname,dob,mail,address,phn,userid,s,cpassword);
				UserOp.insertUser(u);
				
				resp.sendRedirect("index.jsp");
				
				
			}
		}
		
}
