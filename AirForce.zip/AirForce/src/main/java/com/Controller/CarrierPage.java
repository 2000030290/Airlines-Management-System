package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.DAO.UserOp;
import com.Model.Carrier;
import com.Model.User;
@WebServlet("/carrier")
public class CarrierPage extends HttpServlet{

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String cname = req.getParameter("cname");
		int ad30 = Integer.parseInt(req.getParameter("ad30"));
		int ad60 = Integer.parseInt(req.getParameter("ad60"));
		int ad90 = Integer.parseInt(req.getParameter("ad90"));
		int bbook = Integer.parseInt(req.getParameter("bbook"));
		int silver = Integer.parseInt(req.getParameter("silver"));
		int gold = Integer.parseInt(req.getParameter("gold"));
		int plat = Integer.parseInt(req.getParameter("plat"));
		int refund2 = Integer.parseInt(req.getParameter("refund2"));
		int refund10 = Integer.parseInt(req.getParameter("refund10"));
		int refund20 = Integer.parseInt(req.getParameter("refund20"));

		
		if(req.getParameter("ams").equalsIgnoreCase("addCarrier"))
		{
			PrintWriter out = resp.getWriter();
			Carrier c=new Carrier(cname,ad30,ad60,ad90,bbook,silver,gold,plat,refund2,refund10,refund20);
			CarrierOp.insertCarrier(c);
			resp.sendRedirect("adminhome.jsp");
			
		}
		if(req.getParameter("ams").equalsIgnoreCase("Edit"))
		{
			resp.sendRedirect("carrierpg.jsp");
		}
		
	}
}