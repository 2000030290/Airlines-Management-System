package com.Controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/index")
public class LandingPage extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		if(req.getParameter("ams").equalsIgnoreCase("Login"))
		{
			resp.sendRedirect("login.jsp");
			
		}
		if(req.getParameter("ams").equalsIgnoreCase("Register"))
		{
			resp.sendRedirect("register.jsp");
		}
		
	}
}