package com.Controller;

import java.io.IOException;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.FlightOp;
import com.Model.Flight;
@WebServlet("/searchflight")
public class SearchFlightPage extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String origin = req.getParameter("origin");
		String destination = req.getParameter("destination");
		
		List<Flight> fl = new ArrayList<Flight>();
		fl = FlightOp.SearchFlights(origin, destination);
		
		req.setAttribute("fl",fl);
			RequestDispatcher r=req.getRequestDispatcher("userhome.jsp");
			r.forward(req, resp);
		
	}

}
