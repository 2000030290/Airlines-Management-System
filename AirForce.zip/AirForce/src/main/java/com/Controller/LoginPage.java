
package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.UserOp;
import com.Model.User;

@WebServlet("/login")
public class LoginPage  extends HttpServlet 
{
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	if(req.getParameter("ams").equalsIgnoreCase("Login"))
	{
		int uid = Integer.parseInt(req.getParameter("userid"));
		String pwd = req.getParameter("password");
		PrintWriter out = resp.getWriter();
		User u = null;
		int uidd=30727;
		String passwd="Admin@123";
		String pwdd = UserOp.usedDet(uid);
		String original="";
		try
		{
			MessageDigest md=MessageDigest.getInstance("SHA-256");
			byte[] hashedBytes=md.digest(pwd.getBytes());
			StringBuilder sb=new StringBuilder();
			for(byte b: hashedBytes)
			{
				sb.append(String.format("%02x", b));
			}
			original = sb.toString();
		}
		catch(NoSuchAlgorithmException e)
		{
			throw new RuntimeException(e);
		}
	
		if(uidd==(uid) && passwd.equals(pwd)){
			HttpSession session = req.getSession();
			
			session.setAttribute("userid", uid);
			 session.setMaxInactiveInterval( 60);
           resp.sendRedirect("adminhome.jsp");
           }
		else if(original.equals(pwdd))
		{
			HttpSession session = req.getSession();
		session.setAttribute("userid", uid);
		 session.setMaxInactiveInterval( 60);
			req.setAttribute("userid",uid);
			
			RequestDispatcher dis = req.getRequestDispatcher("userhome.jsp");
			dis.forward(req, resp);

		}
		
		else
		{
			out.println("<script>alert('Invalid login')</script>");
			resp.sendRedirect("login.jsp?error=1");
		}
	}
	
	
}
}
