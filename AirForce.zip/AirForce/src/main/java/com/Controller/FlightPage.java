
package com.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.CarrierOp;
import com.DAO.FlightOp;
import com.DAO.UserOp;
import com.Model.Carrier;
import com.Model.Flight;
import com.Model.User;
@WebServlet("/fly")
public class FlightPage extends HttpServlet{

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int cid=Integer.parseInt(req.getParameter("cid"));
		String cname = req.getParameter("cname");
		String origin = req.getParameter("origin");
		String destination = req.getParameter("destination");
		int airfare = Integer.parseInt(req.getParameter("airfare"));
		int bclass = Integer.parseInt(req.getParameter("bclass"));
		int eclass = Integer.parseInt(req.getParameter("eclass"));
		int exclass = Integer.parseInt(req.getParameter("exclass"));

		
		if(req.getParameter("ams").equalsIgnoreCase("AddFlight"))
		{
			PrintWriter out = resp.getWriter();
			Flight c=new Flight(cid,cname,origin,destination,airfare,bclass,eclass,exclass);
			FlightOp.insertFlight(c);
			resp.sendRedirect("adminhome.jsp");
			
		}
		else if(req.getParameter("ams").equalsIgnoreCase("ManageFlight"))
		{
			resp.sendRedirect("editflight.jsp");
		}
			}
}

