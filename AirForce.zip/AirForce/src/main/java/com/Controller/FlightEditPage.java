package com.Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.FlightOp;
import com.Model.Flight;

@WebServlet("/flightedit")
public class FlightEditPage extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	int cid=Integer.parseInt(req.getParameter("cid"));
	String cname = req.getParameter("cname");
//	System.out.println(cname);
	String Origin= req.getParameter("origin");
	String Destination = req.getParameter("destination");
	int Airfare = Integer.parseInt(req.getParameter("airfare"));
	int Eclass = Integer.parseInt(req.getParameter("eclass"));
	int Bclass = Integer.parseInt(req.getParameter("bclass"));
	int Exclass = Integer.parseInt(req.getParameter("exclass"));
	
	if(req.getParameter("ams").equalsIgnoreCase("editflight"))
	{
		Flight c=new Flight(cid,cname,Origin,Destination,Airfare,Eclass,Bclass,Exclass);
		FlightOp.updateFlight(c, cid);
		resp.sendRedirect("editflight.jsp");
	}
	}
	
	
	
}
